SET_ROLE_CHOICES = (
    ('DE', 'Dealer'),
    ('RE', 'Retailer'),
)


SET_HELP_SUPPORT_STATUS = (
    ('PR', 'Processing'),
    ('DN', 'Done')
)

